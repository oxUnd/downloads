fis.config.set('roadmap.path', [
    {
        reg: '**',
        useStandard: false
    }
]);